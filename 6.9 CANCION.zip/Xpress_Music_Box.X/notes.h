/* Microchip Technology Inc. and its subsidiaries.  You may use this software 
 * and any derivatives exclusively with Microchip products. 
 * 
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS".  NO WARRANTIES, WHETHER 
 * EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED 
 * WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A 
 * PARTICULAR PURPOSE, OR ITS INTERACTION WITH MICROCHIP PRODUCTS, COMBINATION 
 * WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION. 
 *
 * IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
 * INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND 
 * WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS 
 * BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE 
 * FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS 
 * IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF 
 * ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
 *
 * MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF THESE 
 * TERMS. 
 */
#ifndef NOTES_H
#define	NOTES_H

/*
 * Define las constantes para la duraci�n de las notas relacionadas con la
 * nota m�s r�pida, que en este caso es la semicorchea.
 */
#define L_W    16 // Redonda
#define L_H_d  12 // Blanca con puntillo
#define L_H     8 // Blanca
#define L_Q_D   6 // Negra con puntillo
#define L_Q     4 // Negra
#define L_E_D   3 // Corchea con puntillo
#define L_E     2 // Corchea
#define L_S     1 // Semicorchea


/*
 * Define la frecuencia de las notas en Hz
 */

#define T_REST 0

// Prmera Octava
#define T_C1  33    // Do
#define T_CS1 35    // Do sostenido
#define T_D1  37    // Re
#define T_DS1 39    // Re sostenido
#define T_E1  41    // Mi
#define T_F1  44    // Fa
#define T_FS1 46    // Fa sostenido
#define T_G1  49    // Sol
#define T_GS1 52   // Sol sostenido
#define T_A1  55   // La
#define T_AS1 58   // La sostenido
#define T_B1  52   // Si
// Segunda Octava
#define T_C2  65    // Do
#define T_CS2 69    // Do sostenido
#define T_D2  73    // Re
#define T_DS2 78    // Re sostenido
#define T_E2  82    // Mi
#define T_F2  87    // Fa
#define T_FS2 93    // Fa sostenido
#define T_G2  98    // Sol
#define T_GS2 104   // Sol sostenido
#define T_A2  110   // La
#define T_AS2 117   // La sostenido
#define T_B2  123   // Si
// Tercera Octava
#define T_C3  131   // Do
#define T_CS3 139   // Do sostenido
#define T_D3  147   // Re
#define T_DS3 156   // Re sostenido
#define T_E3  165   // Mi
#define T_F3  175   // Fa
#define T_FS3 185   // Fa sostenido
#define T_G3  196   // Sol
#define T_GS3 208   // Sol sostenido
#define T_A3  220   // La
#define T_AS3 233   // La sostenido
#define T_B3  247   // Si
// Cuarta Octava
#define T_C4  262   // Do
#define T_CS4 277   // Do sostenido
#define T_D4  294   // Re
#define T_DS4 311   // Re sostenido
#define T_E4  330   // Mi
#define T_F4  349   // Fa
#define T_FS4 370   // Fa sostenido
#define T_G4  392   // Sol
#define T_GS4 415   // Sol sostenido
#define T_A4  440   // La
#define T_AS4 466   // La sostenido
#define T_B4  494   // Si
// Quinta Octava
#define T_C5  523   // Do
#define T_CS5 554   // Do sostenido
#define T_D5  587   // Re
#define T_DS5 622   // Re sostenido
#define T_E5  659   // Mi
#define T_F5  698   // Fa
#define T_FS5 740   // Fa sostenido
#define T_G5  784   // Sol
#define T_GS5 831   // Sol sostenido
#define T_A5  880   // La
#define T_AS5 932   // La sostenido
#define T_B5  988   // Si
// Sexta Octava
#define T_C6  1047  // Do
#define T_CS6 1109  // Do sostenido
#define T_D6  1175  // Re
#define T_DS6 1245  // Re sostenido
#define T_E6  1319  // Mi
#define T_F6  1397  // Fa
#define T_FS6 1480  // Fa sostenido
#define T_G6  1568  // Sol
#define T_GS6 1661  // Sol sostenido
#define T_A6  1760  // La
#define T_AS6 1865  // La sostenido
#define T_B6  1976  // Si
// Septima Octava
#define T_C7  2093  // Do
#define T_CS7 2217  // Do sostenido
#define T_D7  2349  // Re
#define T_DS7 2489  // Re sostenido
#define T_E7  2637  // Mi
#define T_F7  2794  // Fa
#define T_FS7 2960  // Fa sostenido
#define T_G7  3136  // Sol
#define T_GS7 3322  // Sol sostenido
#define T_A7  3520  // La
#define T_AS7 3729  // La sostenido
#define T_B7  3951  // Si


#endif	/* NOTES_H */

