/**
  Generated Main Source File

  Company:
    Microchip Technology Inc.

  File Name:
    main.c

  Summary:
    This is the main file generated using MPLAB(c) Code Configurator

  Description:
    This header file provides implementations for driver APIs for all modules selected in the GUI.
    Generation Information :
        Product Revision  :  MPLAB(c) Code Configurator - 3.15.0
        Device            :  PIC16F18855
        Driver Version    :  2.00
    The generated drivers are tested against the following:
        Compiler          :  XC8 1.35
        MPLAB             :  MPLAB X 3.20
*/

/*
    (c) 2016 Microchip Technology Inc. and its subsidiaries. You may use this
    software and any derivatives exclusively with Microchip products.

    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED
    WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A
    PARTICULAR PURPOSE, OR ITS INTERACTION WITH MICROCHIP PRODUCTS, COMBINATION
    WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION.

    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE,
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS
    BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO THE
    FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN
    ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY,
    THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.

    MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF THESE
    TERMS.
*/

#include "mcc_generated_files/mcc.h"
#include "notes.h"

/*
 * Define la uni�n de una palabra de 24 bits con la estructura de 3 bytes para poder configurar el NCO (24 bits) de forma sencilla mediante los bits Upper/High/Low
 */
typedef union {
    uint24_t word;
    struct {
      uint8_t l_byte;
      uint8_t h_byte;
      uint8_t u_byte;
   };
} ncoinc_t;

/*
 * Define una estructura para manejar los par�metros de cada nota que incluye su duraci�n (length) y frecuencia (pitch) obtenidos de la librer�a notes.h
 */
typedef struct {
    ncoinc_t pitch;
    uint8_t length;
} note_t;

/*
 * Define la funci�n que ajustar� el NCO
 */

void SetNCOFreq(ncoinc_t value){
   NCO1INCU = value.u_byte;
   NCO1INCH = value.h_byte;
   NCO1INCL = value.l_byte;
}

/*
 * Define la funci�n que ajustar� las notas
 */

void delay(uint8_t noteLength){      //function to set length of notes without using the delay function
    do {
        PIR0bits.TMR0IF = 0; // Clear the overflow flag
        TMR0_StartTimer();
        while(!TMR0_HasOverflowOccured()) {};   //wait till the Timer has overflowed after the given period
    } while(--noteLength > 0);
}

/*
 * Definici�n de la melod�a terminada en {0, 0}
 */
const note_t melody[] = {
    {T_A5, L_E}, {T_REST, L_E},{T_C6, L_E_D},
    {T_A5, L_E}, {T_A5, L_S}, {T_D6, L_E}, {T_A5, L_E}, {T_G5, L_E}, 
    {T_A5, L_E}, {T_REST, L_E},{T_E6, L_E_D},
    {T_A5, L_E}, {T_A5, L_S}, {T_F6, L_E}, {T_E6, L_E}, {T_C6, L_E}, 
    {T_A5, L_E}, {T_E6, L_E}, {T_A6, L_E}, {T_A5, L_S}, {T_G5, L_E},
    {T_G5, L_S}, {T_E5, L_E}, {T_B5, L_E}, {T_A5, L_Q_D}, {0, 0}
};

void main(void)
{     
    // Configura el microcontrolador
    SYSTEM_Initialize();
    uint8_t i;
    // Bucle infinito
    while (1){
        NCO1INCU = 0;
        NCO1INCH = 0;
        NCO1INCL = 0;           // Desactiva el NCO
        i=0;
        if(PULSADOR_GetValue() == 0){
            while(melody[i].length!=0){
                //playNote(melody[i]);
                SetNCOFreq(melody[i].pitch);
                delay(melody[i++].length);
                NCO1INCU = 0;
                NCO1INCH = 0;
                NCO1INCL = 0;           // Desactiva el NCO
                __delay_ms(10);         // Pausa entre notas
            }
        }
    }
}
/**
 End of File
*/