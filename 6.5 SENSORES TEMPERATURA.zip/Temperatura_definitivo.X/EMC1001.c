/*
 * File:   EM1001.c
 *
 * "Created in MPLAB Xpress"
 */
#include "EMC1001.h"    // A�ade la librer�a con las definiciones

uint8_t EMC1001_Read(uint8_t reg, uint8_t *pData)
{
    I2C2_MESSAGE_STATUS status = I2C2_MESSAGE_PENDING;
    static I2C2_TRANSACTION_REQUEST_BLOCK trb[2];
    
    // Crea la structura para indicar el registro de lectura
    I2C2_MasterWriteTRBBuild(&trb[0], &reg, 1, EMC1001_ADDRESS);
    // Crea la estructura para la lectura del registro anterior
    I2C2_MasterReadTRBBuild(&trb[1], pData, 1, EMC1001_ADDRESS);                
    // Lanza la comunicaci�n con las estructuras creadas
    I2C2_MasterTRBInsert(2, &trb[0], &status);
    
    while(status == I2C2_MESSAGE_PENDING);      // blocking

    return (status == I2C2_MESSAGE_COMPLETE); 
} 