/* 
 * File:   EM1001.h
 * 
 * "Created in MPLAB Xpress"
 */
#include <xc.h>
#include "mcc_generated_files/i2c2.h"

#ifndef EM1001_H
#define	EM1001_H

#define EMC1001_ADDRESS     0x38   // Direcci�n

//Registros
#define TEMP_HI     0       // 8 bits superiores de la temperatura 
#define TEMP_LO     2       // dos �ltimos bits de la temperatura

// Funcion para la lectura del registro "reg" y
// almacenamiento del valor leido en pData
uint8_t EMC1001_Read(uint8_t reg, uint8_t *pData);

#endif	/* EM1001_H */
